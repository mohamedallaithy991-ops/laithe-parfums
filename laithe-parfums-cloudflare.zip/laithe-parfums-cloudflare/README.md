# LAITHÉ PARFUMS
Cloudflare Workers + Assets + D1 starter.

قبل النشر: أنشئ D1 باسم laithe-parfums-db، نفّذ schema.sql، ثم ضع database_id الحقيقي في wrangler.toml. أضف ADMIN_PASSWORD وADMIN_SECRET وOPENAI_API_KEY كـ Cloudflare Secrets. لا تضع الأسرار داخل public.
