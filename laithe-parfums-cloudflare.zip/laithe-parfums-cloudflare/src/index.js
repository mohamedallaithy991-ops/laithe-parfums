const j=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{'content-type':'application/json;charset=utf-8'}});
async function api(req,e){const u=new URL(req.url),p=u.pathname;
if(p=='/api/health')return j({ok:true});
if(req.method=='GET'&&p=='/api/products')return j((await e.DB.prepare("SELECT p.*,COALESCE((SELECT json_group_array(json_object('id',v.id,'size',v.size,'price',v.price,'stock',v.stock)) FROM variants v WHERE v.product_id=p.id),'[]') variants FROM products p WHERE p.active=1 ORDER BY p.id DESC").all()).results);
if(req.method=='GET'&&p=='/api/shipping')return j((await e.DB.prepare('SELECT * FROM shipping ORDER BY governorate').all()).results);
if(req.method=='GET'&&p=='/api/reviews')return j((await e.DB.prepare('SELECT * FROM reviews WHERE approved=1 ORDER BY id DESC').all()).results);
if(req.method=='POST'&&p=='/api/orders'){let b=await req.json();await e.DB.prepare('INSERT INTO orders(customer_name,phone,governorate,address,items_json,subtotal,shipping,total,payment_ref) VALUES(?,?,?,?,?,?,?,?,?)').bind(b.name,b.phone,b.governorate,b.address,JSON.stringify(b.items||[]),b.subtotal,b.shipping,b.total,b.payment_ref||'').run();return j({ok:true});}
if(req.method=='POST'&&p=='/api/reviews'){let b=await req.json();await e.DB.prepare('INSERT INTO reviews(product_id,customer_name,rating,comment) VALUES(?,?,?,?)').bind(b.product_id,b.customer_name,b.rating,b.comment).run();return j({ok:true});}
if(req.method=='POST'&&p=='/api/ai'){if(!e.OPENAI_API_KEY)return j({reply:'المساعد الذكي يحتاج إضافة OPENAI_API_KEY في Cloudflare Secrets.'});let b=await req.json();let r=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${e.OPENAI_API_KEY}`},body:JSON.stringify({model:e.OPENAI_MODEL||'gpt-4.1-mini',input:`أنت مساعد LAITHÉ PARFUMS. أجب بالعربية البسيطة القريبة من المصري. لا تخترع أسعارًا أو منتجات. سؤال العميل: ${b.message}`})});let d=await r.json();return j({reply:d.output_text||'تعذر الرد الآن'});}
return j({error:'Not found'},404)}
export default{async fetch(req,e){let u=new URL(req.url);return u.pathname.startsWith('/api/')?api(req,e):e.ASSETS.fetch(req)}};
